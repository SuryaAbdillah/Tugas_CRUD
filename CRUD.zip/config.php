<?php
    $server = "localhost";
    $user = "id20026374_suryaabdillah101";
    $password = "Tugaspweb2022.";
    $database = "id20026374_suryaabdillah";

    $db = mysqli_connect($server, $user, $password, $database);

    if(!$db) {
        die("Failed to connect to database: " . mysqli_connect_error());
    }
?>